<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="pl">
<context>
    <name>@default</name>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="1"/>
        <source>Shortcuts</source>
        <translation>Skróty</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="2"/>
        <source>Chat</source>
        <translation>Rozmowa</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="3"/>
        <source>Sent messages' history</source>
        <translation>Historia wysłanych wiadomości</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="4"/>
        <source>Previous message</source>
        <translation>Poprzednia wiadomość</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="5"/>
        <source>Next message</source>
        <translation>Następna wiadomość</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="6"/>
        <source>Previous message from all chats</source>
        <translation>Poprzednia wiadomość ze wszystkich rozmów</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="7"/>
        <source>Next message from all chats</source>
        <translation>Następna wiadomość ze wszystkich rozmów</translation>
    </message>



</context>
</TS>
