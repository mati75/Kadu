QT_TRANSLATE_NOOP( "@default", "Shortcuts"                       );
QT_TRANSLATE_NOOP( "@default", "Chat"                            );
QT_TRANSLATE_NOOP( "@default", "Sent messages' history"          );
QT_TRANSLATE_NOOP( "@default", "Previous message"                );
QT_TRANSLATE_NOOP( "@default", "Next message"                    );
QT_TRANSLATE_NOOP( "@default", "Previous message from all chats" );
QT_TRANSLATE_NOOP( "@default", "Next message from all chats"     );
