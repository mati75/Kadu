<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="pl">
<defaultcodec></defaultcodec>
<context>
    <name>@default</name>
    <message>
        <source>Timeout</source>
        <translation>Czas zaniku</translation>
    </message>
    <message>
        <source>Show message content in hint</source>
        <translation>Pokaż treść wiadomości w dymku</translation>
    </message>
    <message>
        <source>Number of quoted characters</source>
        <translation>Liczba cytowanych znaków</translation>
    </message>
</context>
<context>
    <name>KdeNotify</name>
    <message>
        <source>View</source>
        <translation>Pokaż</translation>
    </message>
    <message>
        <source>Chat</source>
        <translation>Rozmowa</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignoruj</translation>
    </message>
</context>
</TS>
