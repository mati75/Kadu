#ifndef _MODVER_H
#define DESCRIPTION "Notification by KNotify"
#define DESCRIPTION_PL "Modu� powiadamiania u�ytkownika o zdarzeniach za pomoc� KNotify"
#define AUTHOR "Jacek Jab�o�ski"
#define _MODVER_H
#endif
