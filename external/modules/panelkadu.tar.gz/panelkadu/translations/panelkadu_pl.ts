<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="pl">
<context>
    <name>@default</name>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="1"/>
        <source>Geometry</source>
        <translation>Geometria</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="2"/>
        <source>Side</source>
        <translation>Strona</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="3"/>
        <source>Right</source>
        <translation>Prawo</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="4"/>
        <source>Bottom</source>
        <translation>Dół</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="5"/>
        <source>Left</source>
        <translation>Lewo</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="6"/>
        <source>Top</source>
        <translation>Góra</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="7"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>

    <message>
        <location filename="../.configuration-ui-translations.cpp" line="8"/>
        <source>User defined panel length</source>
        <translation>Własna długość panelu</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="9"/>
        <source>Position</source>
        <translation>Pozycja</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="10"/>
        <source>Length</source>
        <translation>Długość</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="11"/>
        <source>Behaviour</source>
        <translation>Zachowanie</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="12"/>
        <source>Activation time</source>
        <translation>Czas aktywacji</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="13"/>
        <source>Hide panel after</source>
        <translation>Ukryj panel po</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="14"/>
        <source>Use activation ranges</source>
        <translation>Używaj przedziałów aktywacji</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="15"/>
        <source>Activation ranges</source>
        <translation>Przedziały aktywacji</translation>
    </message>
    <message>
        <location filename="../.configuration-ui-translations.cpp" line="16"/>
        <source>Use spaces to separate ranges: '0-100 200-300 400-500'</source>
        <translation>Użyj spacji do rozdzielenia przedziałów: '0-100 200-300 400-500'</translation>
    </message>


</context>
</TS>
