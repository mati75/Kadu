/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "configuration_window_widgets.h"
#include "debug.h"

#include "ui_handler.h"

miastoplusa_sms::UIHandler::UIHandler(QObject *parent, char *name)
{
	kdebugf();
}

miastoplusa_sms::UIHandler::~UIHandler()
{
	kdebugf();
}

void miastoplusa_sms::UIHandler::mainConfigurationWindowCreated(MainConfigurationWindow *mainConfigurationWindow)
{
	kdebugf();
	ConfigLineEdit *passLineEdit = dynamic_cast<ConfigLineEdit *>(mainConfigurationWindow->widgetById("miastoplusa_sms/Password"));
	passLineEdit->setEchoMode(QLineEdit::Password);
	kdebugf2();
}

