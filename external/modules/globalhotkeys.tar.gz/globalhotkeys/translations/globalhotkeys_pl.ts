<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="pl">
<context>
	<name>@default</name>

	<message>
		<location filename="" line="0"/>
		<source>Kadu - Global hotkeys</source>
		<translation>Kadu - Skróty globalne</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Hotkey %% is used by another application.</source>
		<translation>Skrót %% jest używany przez inną aplikację.</translation>
	</message>

	<message>
		<location filename="" line="0"/>
		<source>Shortcuts</source>
		<translation>Skróty</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Global hotkeys</source>
		<translation>Skróty globalne</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Show Kadu's main window</source>
		<translation>Pokaż główne okno Kadu</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Hide Kadu's main window</source>
		<translation>Ukryj główne okno Kadu</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Show/hide Kadu's main window</source>
		<translation>Pokaż/ukryj główne okno Kadu</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Chats</source>
		<translation>Rozmowy</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Open incoming chat window</source>
		<translation>Otwórz okno rozmowy przychodzącej</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Open all incoming chat windows</source>
		<translation>Otwórz okna wszystkich rozmów przychodzących</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Minimize all opened chat windows</source>
		<translation>Zminimalizuj wszystkie otwarte okna rozmów</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Restore all minimized chat windows</source>
		<translation>Przywróć wszystkie zminimalizowane okna rozmów</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Minimize/restore all chat windows</source>
		<translation>Zminimalizuj/przywróć wszystkie okna rozmów</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Close all chat windows</source>
		<translation>Zamknij wszystkie okna rozmów</translation>
	</message>
	<message>
		<location filename="" line="0"/>
		<source>Open chat with ...</source>
		<translation>Rozpocznij rozmowę z ...</translation>
	</message>




</context>
</TS>
