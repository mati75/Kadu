<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Agent - new user found</source>
        <translation>Agent - znaleziono użytkownika</translation>
    </message>
</context>
<context>
    <name>Agent</name>
    <message>
        <source>Agent has founded spy&apos;s unknown-users list. Do you want to append this list to agent module?</source>
        <translation>Agent znalazł listę nieznanych osób modułu spy. Czy chcesz ją zaimportować do modułu agenta?</translation>
    </message>
    <message>
        <source>Who has me on list</source>
        <translation>Kto ma mnie na liście</translation>
    </message>
</context>
<context>
    <name>AgentWdg</name>
    <message>
        <source>Last seen</source>
        <translation>Ostatnio widziany</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Uin</source>
        <translation>Numer GG</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Imię</translation>
    </message>
    <message>
        <source>City</source>
        <translation>Miejscowość</translation>
    </message>
    <message>
        <source>Nickname</source>
        <translation>Pseudonim</translation>
    </message>
    <message>
        <source>Birth year</source>
        <translation>Rok urodzenia</translation>
    </message>
    <message>
        <source>Open chat</source>
        <translation>Rozmowa</translation>
    </message>
    <message>
        <source>Add contact</source>
        <translation>Dodaj wybrany kontakt</translation>
    </message>
    <message>
        <source>Remove from list</source>
        <translation>Usuń z listy</translation>
    </message>
    <message>
        <source>Who has me on list?</source>
        <translation>Kto ma mnie na liście?</translation>
    </message>
    <message>
        <source>Warning:
Detected are users, who has chosen option &apos;Private status&apos;
Below is the list of users, who has you on their lists, but you don&apos;t have them on your list</source>
        <translation>Uwaga:
Wykrywane są tylko osoby, które mają ustawioną opcję &apos;Tylko dla znajomych&apos;
Poniżej znajduje się lista osób, które mają Ciebie na liście kontaktów, a których Ty na liście nie masz</translation>
    </message>
</context>
<context>
    <name>NewUserFoundNotification</name>
    <message>
        <source>User &lt;b&gt;%1&lt;/b&gt; has you on his list!</source>
        <translation>Użytkownik &lt;b&gt;%1&lt;/b&gt; ma Cię na swojej liście!</translation>
    </message>
    <message>
        <source>Find user</source>
        <translation>Znajdź osobę</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
</TS>
