#!/bin/bash

/usr/bin/lupdate -noobsolete -verbose *.cpp -ts translations/agent_pl.ts
