This is emoticons Tango theme for Kadu instant messenger ( http://www.kadu.net/ )
Theme maintainer: Piotr Pełzowski (pelzowski at gmail dot com)


If you have any questions ask maintainer directly or ask on http://www.kadu.net/forum/  


- Tango emoticons theme is licensed under the GNU General Public License. (http://www.gnu.org/licenses/gpl.html). Oryginaly made for Pidgin ( http://pidgin.im/ ) by Hylke Bons ( http://bomahy.nl/hylke/blog/ )


- Authors of other icons:
License: GPL

Kamil Dziedzic, (arvenil)  kamil at klecza dot pl
	learning.gif

Łukasz Florczak (sarven)   lucas at sarven dot pl
	magician.gif
	bathtub.gif

Mariusz Waluga (dylemat) mariuszko at interia dot pl
	hold_out.gif
	daydreamer.gif
	read_this.gif
	annoy.gif
	dresiarz.gif
	ass.gif
	bloomer.gif
	ganja.gif
	idiot.gif
	hello.gif
	apple.gif
	twisted.gif
	calmly.gif
	learning.gif
	okok.gif
	strongman.gif
	admonish.gif
	slap.gif
	help.gif
	shower.gif
	prompt.gif
	puke.gif
	wall.gif
	sex.gif
	wine.gif
	tuptup.gif
	mouths.gif
	exclamation_mark.gif
	shopping.gif

Karolina Weiss (karolina) (linuxozaurus) karolina_enternauta at wp dot pl
	newspaper.gif

Piotr Pełzowski (patpi) pelzowski at gmail dot com
	snow.png